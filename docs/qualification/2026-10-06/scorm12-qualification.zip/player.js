(() => {
    const state = { scenes: [], completionSettings: { passingScore: 80, includeOptionalAssessments: false }, current: 0, visited: new Set(), completedAudio: new Set(), assessments: {}, remediation: null, startedAt: Date.now() };
  let api = null;
    let lmsWarningShown = false;
    function runtimeStatus(message) { const status = document.querySelector("#runtime-status"); if (status) status.textContent = message; }
  function findApi() {
    let view = window;
    while (view && view.parent && view.parent !== view) { view = view.parent; if (view.API) return view.API; }
    return window.API || null;
  }
    function call(name, value) { name = { Initialize: "LMSInitialize", GetValue: "LMSGetValue", SetValue: "LMSSetValue", Commit: "LMSCommit", Terminate: "LMSFinish" }[name] || name; if (!api) return ""; try { return api[name](...value); } catch (_) { if (!lmsWarningShown) { lmsWarningShown = true; runtimeStatus("LMS tracking is unavailable; progress will not be reported."); } return ""; } }
  function save() {
    call("SetValue", ["cmi.core.lesson_location", String(state.current)]);
        call("SetValue", ["cmi.suspend_data", JSON.stringify({ current: state.current, visited: [...state.visited], completedAudio: [...state.completedAudio], assessments: state.assessments, remediation: state.remediation })]);
    call("Commit", [""]); 
  }
    function settings(scene) { return scene.assessmentSettings || { maxAttempts: 2, passingScore: 100, scoreWeight: 1, remediationSceneId: null }; }
    function assessmentCorrect(item, result) {
        if (item.type === "single-choice" || item.type === "true-false") return result.response.length === 1 && result.response[0] === item.correctResponse;
        if (item.type === "multiple-response") return [...result.response].sort().join("|") === [...item.correctResponses].sort().join("|");
        if (item.type === "ordering") return result.response.join("|") === item.correctOrder.join("|");
        if (item.type === "drag-drop" || item.type === "matching") return item.correctMatches.every(pair => result.matches[pair.sourceIdentifier] === pair.targetIdentifier) && Object.keys(result.matches).length === item.correctMatches.length;
        const answer = item.caseSensitive ? result.textResponse.trim() : result.textResponse.trim().toLocaleLowerCase();
        return item.acceptedAnswers.some(value => answer === (item.caseSensitive ? value.trim() : value.trim().toLocaleLowerCase()));
    }
    function assessmentHtml(scene) {
        const item = scene.assessmentItem;
        if (!item) return "";
        const result = state.assessments[scene.id] || { response: [], matches: {}, textResponse: "", attempts: 0, isCorrect: null };
        const disabled = result.isCorrect === true || result.attempts >= settings(scene).maxAttempts;
        const choiceList = item.type === "single-choice" || item.type === "multiple-response" || item.type === "ordering" ? item.choices : item.type === "true-false" ? [{ identifier: "true", text: "True" }, { identifier: "false", text: "False" }] : [];
        let controls = "";
        if (item.type === "single-choice" || item.type === "true-false" || item.type === "multiple-response") controls = choiceList.map(choice => `<label><input type="${item.type === "multiple-response" ? "checkbox" : "radio"}" name="assessment-response" value="${escapeHtml(choice.identifier)}" ${result.response.includes(choice.identifier) ? "checked" : ""} ${disabled ? "disabled" : ""}> ${escapeHtml(choice.text)}</label>`).join("");
        if (item.type === "ordering") controls = choiceList.map((choice, index) => `<label>${index + 1}. <select data-order-index="${index}" ${disabled ? "disabled" : ""}><option value="">Choose</option>${choiceList.map(option => `<option value="${escapeHtml(option.identifier)}" ${result.response[index] === option.identifier ? "selected" : ""}>${escapeHtml(option.text)}</option>`).join("")}</select></label>`).join("");
        if (item.type === "matching" || item.type === "drag-drop") { const sources = item.type === "matching" ? item.leftItems : item.draggables; const targets = item.type === "matching" ? item.rightItems : item.targets; controls = sources.map(source => `<label>${escapeHtml(source.text)} <select data-match-source="${escapeHtml(source.identifier)}" ${disabled ? "disabled" : ""}><option value="">Choose a match</option>${targets.map(target => `<option value="${escapeHtml(target.identifier)}" ${result.matches[source.identifier] === target.identifier ? "selected" : ""}>${escapeHtml(target.text)}</option>`).join("")}</select></label>`).join(""); }
        if (item.type === "short-answer") controls = `<label>Your answer <input data-text-response maxlength="1000" value="${escapeHtml(result.textResponse)}" ${disabled ? "disabled" : ""}></label>`;
        const outcome = result.attempts ? `<p>${result.isCorrect ? escapeHtml(item.correctFeedback) : escapeHtml(item.incorrectFeedback)} Score: ${result.isCorrect ? 100 : 0}% (${result.attempts}/${settings(scene).maxAttempts} attempts).</p>` : "";
        const remediation = result.isCorrect === false && settings(scene).remediationSceneId ? `<button type="button" data-remediation="${escapeHtml(settings(scene).remediationSceneId)}">Review lesson</button>` : "";
        return `<section class="assessment"><h3>${escapeHtml(item.prompt)}</h3><form id="assessment-form">${controls}<button type="submit" ${disabled ? "disabled" : ""}>${result.attempts ? "Try again" : "Check answer"}</button>${outcome}${remediation}</form></section>`;
    }
    function finish() {
        const required = state.scenes.filter(scene => scene.required);
        const complete = state.scenes.length > 0 && required.every(scene => { if (!state.visited.has(scene.id)) return false; if (!scene.assessmentItem) return true; const result = state.assessments[scene.id]; const config = settings(scene); return result && result.attempts > 0 && (result.isCorrect === true || result.attempts >= config.maxAttempts); }) && state.scenes.filter(scene => scene.audioRequired).every(scene => scene.audioAssets.length > 0 && scene.audioAssets.every(id => state.completedAudio.has(`${scene.id}:${id}`)));
        const scored = state.scenes.filter(scene => scene.assessmentItem && (scene.required || (state.completionSettings.includeOptionalAssessments && (state.assessments[scene.id]?.attempts || 0) > 0)));
        const totalWeight = scored.reduce((sum, scene) => sum + settings(scene).scoreWeight, 0);
        const score = totalWeight ? Math.round(scored.reduce((sum, scene) => sum + (state.assessments[scene.id]?.isCorrect === true ? 100 : 0) * settings(scene).scoreWeight, 0) / totalWeight) : null;
        const passed = complete && (score === null || score >= state.completionSettings.passingScore);
        call("SetValue", ["cmi.core.lesson_status", complete ? "completed" : "incomplete"]);
        call("SetValue", ["cmi.core.lesson_status", complete ? (passed ? "passed" : "failed") : "incomplete"]);
    call("SetValue", ["cmi.core.score.min", "0"]);
    call("SetValue", ["cmi.core.score.max", "100"]);
        call("SetValue", ["cmi.core.score.raw", String(score ?? 0)]);
        call("SetValue", ["cmi.core.score.scaled", String((score ?? 0) / 100)]);
    save();
  }
    function text(scene) {
        const paragraphs = (scene.extractedText || []).filter(Boolean).map(value => `<p>${escapeHtml(value)}</p>`).join("");
        return scene.previewImage && paragraphs ? `<details><summary>Read slide text</summary>${paragraphs}</details>` : paragraphs;
    }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[char])); }
    function bindAssessment(scene) {
        const form = document.querySelector("#assessment-form");
        if (!form) return;
        const current = () => state.assessments[scene.id] || { response: [], matches: {}, textResponse: "", attempts: 0, isCorrect: null };
        form.querySelectorAll("[name=assessment-response]").forEach(input => input.addEventListener("change", () => { const response = [...form.querySelectorAll("[name=assessment-response]:checked")].map(entry => entry.value); state.assessments[scene.id] = { ...current(), response, isCorrect: null }; }));
        form.querySelectorAll("[data-order-index]").forEach(input => input.addEventListener("change", () => { const response = [...form.querySelectorAll("[data-order-index]")].sort((a, b) => Number(a.dataset.orderIndex) - Number(b.dataset.orderIndex)).map(entry => entry.value).filter(Boolean); state.assessments[scene.id] = { ...current(), response, isCorrect: null }; }));
        form.querySelectorAll("[data-match-source]").forEach(input => input.addEventListener("change", () => { const matches = { ...current().matches, [input.dataset.matchSource]: input.value }; state.assessments[scene.id] = { ...current(), matches, isCorrect: null }; }));
        const textInput = form.querySelector("[data-text-response]");
        if (textInput) textInput.addEventListener("input", () => { state.assessments[scene.id] = { ...current(), textResponse: textInput.value, isCorrect: null }; });
        form.addEventListener("submit", event => { event.preventDefault(); const result = current(); const hasResponse = result.response.length || Object.keys(result.matches).length || result.textResponse.trim().length; if (!hasResponse || result.isCorrect === true || result.attempts >= settings(scene).maxAttempts) return; state.assessments[scene.id] = { ...result, attempts: result.attempts + 1, isCorrect: assessmentCorrect(scene.assessmentItem, result) }; render(); });
        const remediation = form.querySelector("[data-remediation]");
        if (remediation) remediation.addEventListener("click", () => { state.remediation = { assessmentSceneId: scene.id, remediationSceneId: remediation.dataset.remediation }; state.current = state.scenes.findIndex(item => item.id === remediation.dataset.remediation); save(); render(); });
    }
  function render() {
    const scene = state.scenes[state.current];
    if (!scene) return;
    state.visited.add(scene.id);
    document.querySelector("#scene-title").textContent = scene.title;
    const body = document.querySelector("#scene-body");
    body.innerHTML = (state.remediation && state.remediation.remediationSceneId === scene.id ? `<button type="button" data-return-assessment>Return to question</button>` : "") + text(scene);
    if (scene.previewImage) {
        const slideImage = document.createElement("img");
        slideImage.src = scene.previewImage;
        slideImage.alt = `Slide ${scene.sourceSlide || state.current + 1}: ${scene.title || "Untitled scene"}`;
        slideImage.style.display = "block";
        slideImage.style.maxWidth = "100%";
        slideImage.style.maxHeight = "520px";
        slideImage.style.objectFit = "contain";
        slideImage.style.margin = "0 auto 16px";
        slideImage.style.background = "#fff";
        slideImage.addEventListener("error", () => { runtimeStatus("Slide preview could not be loaded; slide text remains available below."); slideImage.remove(); });
        body.prepend(slideImage);
    }
    document.querySelector("#scene-assessment").innerHTML = assessmentHtml(scene);
    bindAssessment(scene);
    const returnButton = document.querySelector("[data-return-assessment]");
    if (returnButton) returnButton.addEventListener("click", () => { state.current = state.scenes.findIndex(item => item.id === state.remediation.assessmentSceneId); state.remediation = null; save(); render(); });
    const media = document.querySelector("#scene-media"); media.innerHTML = "";
    (scene.imageAssets || []).forEach(id => { const asset = window.__CHIMERA_ASSETS[id]; if (!asset) return; const image = document.createElement("img"); image.src = asset.path; image.alt = scene.decorativeImages.includes(id) ? "" : (scene.imageAltText[id] || asset.filename); image.setAttribute("role", image.alt ? "img" : "presentation"); image.addEventListener("error", () => runtimeStatus(`Media could not be loaded: ${asset.filename}`)); media.appendChild(image); });
    (scene.audioAssets || []).forEach(id => { const asset = window.__CHIMERA_ASSETS[id]; if (!asset) return; const audio = document.createElement("audio"); audio.controls = true; audio.preload = "metadata"; audio.src = asset.path; audio.addEventListener("error", () => runtimeStatus(`Audio could not be loaded: ${asset.filename}`)); if (scene.audioRequired) audio.addEventListener("ended", () => { state.completedAudio.add(`${scene.id}:${id}`); save(); finish(); }); media.appendChild(audio); });
    const status = document.querySelector("#scene-status"); status.textContent = `${state.current + 1} / ${state.scenes.length}`;
    document.querySelector("#previous").disabled = state.current === 0;
    document.querySelector("#next").disabled = state.current === state.scenes.length - 1;
    finish();
  }
  async function start() {
        api = findApi(); if (!api) runtimeStatus("Preview mode: no LMS tracking connection detected."); if (api) { api.LMSInitialize(""); const location = Number(api.LMSGetValue("cmi.core.lesson_location")); if (Number.isInteger(location) && location >= 0) state.current = location; try { const saved = JSON.parse(api.LMSGetValue("cmi.suspend_data") || "{}"); (saved.visited || []).forEach(id => state.visited.add(id)); (saved.completedAudio || []).forEach(key => state.completedAudio.add(key)); state.assessments = saved.assessments || {}; state.remediation = saved.remediation || null; } catch (_) {} }
    const response = await fetch("storyboard.json"); const storyboard = await response.json(); state.scenes = storyboard.scenes || []; state.completionSettings = storyboard.completionSettings || state.completionSettings;
    window.__CHIMERA_ASSETS = Object.fromEntries((storyboard.assets || []).map(asset => [asset.id, { ...asset, path: asset.path }]));
    document.querySelector("#previous").onclick = () => { state.current -= 1; save(); render(); };
    document.querySelector("#next").onclick = () => { state.current += 1; save(); render(); };
    document.querySelector("#course-title").textContent = storyboard.title || "Chimera course";
    render();
  }
  window.addEventListener("beforeunload", () => { save(); if (api) { api.LMSSetValue("cmi.core.session_time", "PT" + Math.floor((Date.now() - state.startedAt) / 1000) + "S"); api.LMSFinish(""); } });
  start().catch(error => { document.querySelector("#scene-body").textContent = `Course could not be loaded: ${error.message}`; });
})();
